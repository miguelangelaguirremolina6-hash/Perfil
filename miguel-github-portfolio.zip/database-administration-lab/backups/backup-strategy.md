Daily backups using cron jobs.
