# Database Administration Lab

Administración de bases de datos.

## Contenido
- Queries SQL
- Backups
- Optimización
