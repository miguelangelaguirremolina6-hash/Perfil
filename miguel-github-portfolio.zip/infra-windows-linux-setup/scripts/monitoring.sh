#!/bin/bash
echo 'Monitoring system...'
top
