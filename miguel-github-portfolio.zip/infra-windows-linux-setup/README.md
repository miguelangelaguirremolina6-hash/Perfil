# Infraestructura Windows & Linux Setup

Repositorio enfocado en la implementación y administración de servidores Windows y Linux.

## Contenido
- Active Directory
- Configuración de servicios Linux
- Scripts de automatización

## Tecnologías
Windows Server, Linux, Bash, PowerShell
